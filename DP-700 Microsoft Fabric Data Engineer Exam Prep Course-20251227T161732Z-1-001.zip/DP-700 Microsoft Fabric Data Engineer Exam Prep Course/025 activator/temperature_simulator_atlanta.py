# INSTALL azure-eventhub before running!
# pip command:
# pip install azure-eventhub

from azure.eventhub import EventHubProducerClient, EventData
from datetime import datetime, timezone
import hashlib
import random
import time
import json

# Replace the placeholders with your Event Hubs connection string and event hub name
EVENTHUB_NAME = 'xxx'
CONNECTION_STR = 'xxx'


# Configuration variables
MIN_TEMPERATURE = 19.0          # Minimum temperature value
MAX_TEMPERATURE = 20.0          # Maximum temperature value
LOCATION = "Atlanta, USA"       # Location
SLEEP_TIME = 3                  # Sleep time before sending next event

# Example message
'''
{
    "location": "Atlanta, USA".
    "timestamp": "2025-07-12T12:36:03.826769+00:00",
    "temperature": 19.5
    "event_id": "88709af29e138d8d906e009a800ebaddacd46d89d20ec91151e2ab91557170c5"
}
'''

# Create a producer client to send messages to the event hub
producer = EventHubProducerClient.from_connection_string(conn_str=CONNECTION_STR, eventhub_name=EVENTHUB_NAME)

def generate_fake_temperature(min_temp, max_temp):
    """Simulate a fake temperature reading within the specified range"""
    return round(random.uniform(min_temp, max_temp), 2)

def generate_event_id(payload):
    """Generate a SHA256 hash as a unique event ID."""
    hash_object = hashlib.sha256(json.dumps(payload, sort_keys=True).encode('utf-8'))
    return hash_object.hexdigest()

def get_current_timestamp():
    """Return the current timestamp in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat()

try:
    # Continuously generate and send fake temperature readings
    while True:
        # Create a batch.
        event_data_batch = producer.create_batch()
        
        # Create the payload
        payload = {
            "location": LOCATION,
            "timestamp": get_current_timestamp(),
            "temperature": generate_fake_temperature(MIN_TEMPERATURE, MAX_TEMPERATURE)
        }
        
        # Generate an event_id
        payload["event_id"] = generate_event_id(payload)
        
        # Format the message as JSON
        message = json.dumps(payload)

        # Add the JSON-formatted message to the batch
        event_data_batch.add(EventData(message))
        
        # Send the batch of events to the event hub
        producer.send_batch(event_data_batch)
        
        print(json.dumps(json.loads(message), indent=4))
        print(event_data_batch)
        
        # Wait for a bit before sending the next reading
        time.sleep(SLEEP_TIME)
except KeyboardInterrupt:
    print("Stopped by the user")
except Exception as e:
    print(f"Error: {e}")
finally:
    # Close the producer
    producer.close()