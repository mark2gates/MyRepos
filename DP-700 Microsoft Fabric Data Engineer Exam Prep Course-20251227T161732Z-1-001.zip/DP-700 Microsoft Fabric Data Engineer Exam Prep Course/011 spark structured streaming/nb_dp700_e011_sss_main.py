#!/usr/bin/env python
# coding: utf-8

# ## nb_dp700_e011_sss_main
# 
# New notebook

# In[1]:


from pyspark.sql.types import StructType, StringType, DoubleType, TimestampType
import os
import json
import pyspark.sql.functions as F
import time

source_path = "Files/dp700_e011/source"
checkpoint_path = "Files/dp700_e011/checkpoint"
schema_name = "dp700_e011"
table_name = "temperature_stream"

# Schema for incoming JSON data
file_schema = StructType() \
    .add("id", StringType()) \
    .add("temperature", DoubleType()) \
    .add("timestamp", TimestampType())


# In[3]:


# Read streaming data to unbounded table/dataframe
raw_stream_df = spark.readStream \
    .schema(file_schema) \
    .option("maxFilesPerTrigger", 1) \
    .json(source_path)

# Example transformation that adds a processed_timestamp column to the data
transformed_stream_df = raw_stream_df \
    .withColumn("processed_timestamp", \
    F.current_timestamp())

# Stream data to a delta table
deltastream = transformed_stream_df.writeStream \
            .format("delta") \
            .outputMode("append") \
            .option("checkpointLocation", checkpoint_path) \
            .start(f"Tables/{schema_name}/{table_name}")


# In[4]:


raw_stream_df.isStreaming


# In[5]:


deltastream.isActive


# In[8]:


deltastream.status


# In[9]:


deltastream.lastProgress


# In[11]:


while deltastream.isActive:
    print("✅ Stream is running...")
    print("📊 Last progress:", deltastream.lastProgress)
    time.sleep(5)

print("❌ Stream has stopped.")


# In[10]:


deltastream.stop()


# In[12]:


df = spark.sql("SELECT * FROM lh_dp700.dp700_e011.temperature_stream")
display(df)

