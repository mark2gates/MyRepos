-- Create schema if not exists
CREATE SCHEMA IF NOT EXISTS dp700_e013;

-- Create the employees table
CREATE TABLE IF NOT EXISTS dp700_e013.employees (
    employee_id INT,
    name STRING,
    department_id INT,
    hire_date DATE,
    salary DECIMAL(10, 2)
);

INSERT INTO dp700_e013.employees VALUES
    (10, 'Lily Morgan', 104, '2024-12-10', 71000.00),
    (11, 'Noah Carter', 103, '2025-02-05', 69000.00);